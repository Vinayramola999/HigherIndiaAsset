// import React, { useState } from "react";
// import login from "../assests/login.jpg";

// const LoginForm = () => {
//     const [email, setEmail] = useState("");

//     const handleEmailChange = (e) => {
//         setEmail(e.target.value);
//     };

//     const handleSubmit = (e) => {
//         e.preventDefault();
//     };

//     return (
//         <div className="h-screen flex bg-white">
//             <div className="w-1/2 flex justify-center items-center">
//                 <img src={login} alt="Login Illustration" className="object-cover h-[100%]" />
//             </div>
//             <form onSubmit={handleSubmit} className="flex flex-col  items-center ml-[15%] mt-[12%] font-medium text-black rounded-none max-w-[350px]">
//                 <header className="text-center">
//                     <img
//                         loading="lazy"
//                         src="https://cdn.builder.io/api/v1/image/assets/TEMP/3d9cb39f648d5a41315200385261ec9c618f5641ff5dcea3d517780a70a1023d?placeholderIfAbsent=true&apiKey=f4328c4a551b4b9fa165bba17dc932db"
//                         alt="Login logo"
//                         className="object-contain self-center aspect-square ml-[37%] w-[45px]"
//                     />
//                     <h1 className="mt-5 text-2xl font-semibold text-black">
//                         Login with your account
//                     </h1>
//                     <p className="mt-1 text-base text-zinc-600">
//                         Provide your registered email
//                     </p>
//                 </header>
//                 <main className="mt-10">
//                     <div>
//                         <label htmlFor="emailInput" className="text-sm text-black">
//                             Email
//                         </label>
//                         <div className="flex gap-5 px-3 py-3.5 mt-2 text-xs whitespace-nowrap rounded-xl border border-black border-solid bg-zinc-50 text-neutral-400">
//                             <img
//                                 loading="lazy"
//                                 src="https://cdn.builder.io/api/v1/image/assets/TEMP/29fd2e30017df1de28c44da98f9ed87ee2383917ddf05dd846203fcd9ee14538?placeholderIfAbsent=true&apiKey=f4328c4a551b4b9fa165bba17dc932db"
//                                 alt="Email icon"
//                                 className="object-contain shrink-0 w-5 aspect-square"
//                             />
//                             <input
//                                 type="email"
//                                 id="emailInput"
//                                 value={email}
//                                 onChange={handleEmailChange}
//                                 placeholder="example@gmail.com"
//                                 className="flex-auto my-auto w-[266px] bg-transparent"
//                                 required
//                                 aria-required="true"
//                             />
//                         </div>
//                     </div>
//                     <button
//                         type="submit"
//                         className="px-16 py-3.5 mt-10 w-full text-sm text-white whitespace-nowrap bg-blue-700 rounded-xl hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors"
//                     >
//                         Continue
//                     </button>
//                 </main>
//             </form>
//         </div>
//     );
// };
// export default LoginForm;









import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import login from '../assests/login.jpg';

const Login = () => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPopup, setShowPopup] = useState(false);
  const [popupMessage, setPopupMessage] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const storedEmail = localStorage.getItem('email');
    if (storedEmail) {
      setEmail(storedEmail);
    }
  }, []);

  const handleLogin = async (e) => {
    e.preventDefault();
    if (loading) return;
    if (!email) {
      setError('Email is required');
      return;
    }
    if (!validateEmail(email)) {
      setError('Please enter a valid email address');
      return;
    }
    setLoading(true);
    try {
      const response = await axios.post('http://43.204.140.118:3001/mail-verify', {
        email,
      })
      if (response.status === 403) {
        if (response.data.error === "Password reset required. Please change your password before logging in.") {
          setPopupMessage('You are a new user. Please proceed to change your password.');
          setShowPopup(true);
        } else if (response.data.message === "User found. You can proceed to login") {
          navigate('/SuperLogin');
        } else {
          navigate('/verify', { state: { email } });
        }
      }
    } catch (err) {
      console.error('Error during OTP request:', err);
      setError('Failed to send OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const validateEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const handleNext = async () => {
    setShowPopup(false); // Close the popup
    try {
      const response = await axios.post('http://43.204.140.118:3001/request-otp', { email });
      if (response.status === 200) {
        navigate('/verify', { state: { email } });
      }
    } catch (err) {
      console.error('Error during OTP request:', err);
      setError('Failed to send OTP. Please try again.');
    }
  };

  return (
    <div>
      <div className="h-screen flex bg-white">
        <div className="w-1/2 flex justify-center items-center">
          <img src={login} alt="Login Illustration" className="object-cover h-[100%]" />
        </div>
        <form
          onSubmit={handleLogin}
          className="flex flex-col items-center ml-[15%] mt-[12%] font-medium text-black rounded-none max-w-[350px]"
        >
          <header className="text-center">
            <img
              loading="lazy"
              src="https://cdn.builder.io/api/v1/image/assets/TEMP/3d9cb39f648d5a41315200385261ec9c618f5641ff5dcea3d517780a70a1023d?placeholderIfAbsent=true&apiKey=f4328c4a551b4b9fa165bba17dc932db"
              alt="Login logo"
              className="object-contain self-center aspect-square ml-[37%] w-[45px]"
            />
            <h1 className="mt-5 text-2xl font-semibold text-black">Login with your account</h1>
            <p className="mt-1 text-base text-zinc-600">Provide your registered email</p>
          </header>
          <main className="mt-10">
            <div>
              <label htmlFor="emailInput" className="text-sm text-black">Email</label>
              <div className="flex gap-5 px-3 py-3.5 mt-2 text-xs whitespace-nowrap rounded-xl border border-black border-solid bg-zinc-50 text-neutral-400">
                <img
                  loading="lazy"
                  src="https://cdn.builder.io/api/v1/image/assets/TEMP/29fd2e30017df1de28c44da98f9ed87ee2383917ddf05dd846203fcd9ee14538?placeholderIfAbsent=true&apiKey=f4328c4a551b4b9fa165bba17dc932db"
                  alt="Email icon"
                  className="object-contain shrink-0 w-5 aspect-square"
                />
                <input
                  type="email"
                  id="emailInput"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@gmail.com"
                  className="flex-auto my-auto w-[266px] bg-transparent"
                  required
                  aria-required="true"
                />
              </div>
            </div>
            {error && <p className="text-red-600 text-sm mb-4">{error}</p>} {/* Show error message */}
            <button
              type="submit"
              className="px-16 py-3.5 mt-10 w-full text-sm text-white whitespace-nowrap bg-blue-700 rounded-xl hover:bg-blue-800 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 transition-colors"
              disabled={loading} // Disable button while loading
            >
              {loading ? 'Sending...' : 'Continue'}
            </button>
          </main>
        </form>
      </div>

      {/* Popup for new user message */}
      {showPopup && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-5 rounded-lg shadow-lg">
            <h2 className="text-lg font-bold">{popupMessage}</h2>
            <button
              onClick={handleNext}
              className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Next
            </button>
            <button
              onClick={() => setShowPopup(false)}
              className="mt-2 px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
export default Login;